# Handoff — current state and next actions

Updated **23 November 2026**. Previous pushed checkpoint: **0d4aee9**; `git log -1` identifies this checkpoint.
Read [AGENTS](AGENTS.md), then this file and [PLAN](PLAN.md). Detailed history is indexed in
[docs/README](docs/README.md); do not read archives as current instructions.

## State

- **Delivered:** engine-v1.3-r2 (unchanged v1.3 nodes), Rule3, D29 targets/pool0, row-local rotation fit;
  10k worlds/branch through canonical1k chunks on ten workers. Team-pathway-v1 starts tomorrow.
- **Scope/progress:** original14-task programme64% (S01–S08 complete; S13 deferred). D42 Chunk A
  **58%** = A1 **100%**×30% + A2 **80%**×35% + A3 **0%**×35%; B0. Finish A2 only, then stop.
- A1 outcomes/ten-rung ledger: [completed checkpoint](docs/checkpoints/2026-11-23-a1.md).
  [Release receipt](analysis/experiments/20261123_r2_release_v1.json). Fresh200 F4 establishes27/27
  proper bounds plus all bias/coverage diagnostics; original protected v2 42/44 preserved, never repeated.
  Post-result v3 revision is explicit; no universal player-accuracy or learned availability claim.
- **A2:** analytical contextual-clock screens/confirmation and200-game engine development passed. Shared
  shooting has no confirmed pooled missing PTS covariance, so no calibrated form factor was added.
- **A2 steps1–2 complete:** development/confirmation panels, seed diagnostic, three10k stresses,
  unchanged-resume41 files and six exact raw wiring checks. **Step3 final246 is running** on ten workers;
  source/criteria frozen. Production remains r2. Step4 includes delivery, the requested scorer/diagnostic
  audit and document consolidation. [Evidence](docs/research/a2_clock_evidence_20261123.md).
  Do not repeat completed A1 simulations. Review server:8767; never stop owner:8766. D52: no CI workflows.

## Latest published PWA delivery

- Origin23Nov, generation**2026-11-23T18:06:16Z**;63requests/0failures, required advanced rebuild231.9s.
  10games/15×10k batches; snapshot1184.0s. All53,732 histogram checks pass. Season80,337 weighted
  paths/mass100k/952games; every original near-term atom exact. No iid-season/calibration claim.
- Public data-free shell31317f88/cache318fb2858f9d58651de0 is unchanged. New iCloud laptop
  **215,095,062 bytes**, phone**110,224,058**. Both require manual device import; real-device acceptance
  is unverified. No incremental bundle publication yet. Assets support r2 through loaded metadata.
- Hosted final imports/offline**29/29 laptop,27/27 phone**; smoke**108/108**, fault**86/108/exit1**.
  Original asset delivery also passed installed upgrade32/32 and inspected normal-route24/24 at
  1440/960/390 in both themes. Live output/model/bundle contracts are verified; no further asset push needed.
- Receipts `20261123_r2_{integrated_delivery,live_accounting,season_accounting}_v1.json`.
  Logs `/tmp/musnba_a1_r2_world_queue_nightly_20261123_v1.log` and
  `/tmp/musnba_r2_delivery_{checks,smoke,fault,pwa_phone,pwa_laptop}_20261123_v1.log`.
  Live root `data/derived/live_runs/2026-11-23-1795455992573123000` retained for replay.

## Fixed A2 finish

Main development/confirmation screens are complete. Close through four stages only: (1) finish current
three-game10k stress and resume accounting; (2) wire/freeze the unchanged clock recipe and prove raw parity;
(3) one protected246-game score for a survivor, otherwise retain r2; (4) fresh accepted-engine nightly,
both PWA exports/checks, closing scorer audit/document consolidation, commit/push. A failed gate records no-release and proceeds to final delivery;
no new tuning loop, feature family, extra diagnostic study or broader refactor. D54/A3/zones stay future.
Required correctness/delivery checks ride these stages; then A2 stops. Clarified23Nov after the owner's
request for a finite finish, without changing the frozen acceptance rules.

## Next actions

1. **A2 headliner:** test the frozen contextual late-clock correction in the engine against real outcomes.
   Hook-off three raw r2 pilots pass; sampler3/3. Runtime manifest
   `20261123_a2_clock_engine_runtime_manifest_v1.json` freezes current sources, unchanged pools/IDs/primary
   and r2 baseline. Earlier-fold planned config aliases resolve via retained preparation records; model
   identities/IDs/seeds are unchanged. Engine hook is opt-in only; production r2 timing remains legacy.
   Use qualified r2 in both arms, reserve r3 for clock; no new form/variance factor or feature selection.
   Read [original engine stages](docs/protocols/a2_clock_engine_20261123.md) and the prospective
   [v3 development plan](docs/protocols/a2_clock_v3_development_20261123.md). Pools are already frozen
   under `data/derived/experiments/20261123_a2_late_clock_{screen,confirmation}_v1/F*_pools.json`;
   IDs in `20261123_a2_clock_engine_panels_v1.json`. Freeze driver/source/input/seed identities before results.
2. **Research checkpoint complete:** [A2 engine evidence](docs/research/a2_clock_evidence_20261123.md)
   owns populations/effects/accounting. Receipt `20261123_a2_research_checkpoint_v1.json`: smoke108/108,
   deliberate fault86/108 exit1, sampler/recipe5/5. Independent raw-table audit reproduces all600 input
   decisions/300 selected IDs,12,950 roster and127,610 template position cells. Production/PWA unchanged;
   no repeated nightly at this research-only checkpoint. All research stages complete; final246 owns ten compute workers.
3. **Step3 active:** session62907, `/tmp/musnba_a2_clock_final_20261123_v1.log`;
   `analysis/a2_clock_release.py run --jobs 10`, all five inner-thread limits1. Exactly246 protected
   games; r2 controls hard-linked/reused, only r3 candidates simulate/audit inside the ten workers.
   Scorer99768 (`/tmp/musnba_a2_clock_final_score_once_20261123_v1.py`) waits full run+audit, scores
   once; log `/tmp/musnba_a2_clock_final_scores_20261123_v1.log`. No auto promotion.
   **Do not edit frozen scorer/engine/input/protocol files or inspect interim quality.** Progress counts
   allowed. Runtime recipe `20261123_a2_clock_runtime_recipe_v1.json`; frozen final manifest
   `20261123_a2_clock_final_manifest_v1.json`; exact31-file source copy
   `data/derived/experiments/a2_clock_final_20261123_v1_sources/`.
   Pools use55,371 prior rows, latest13Jun, cutoff30Jun2026; loaded-origin guards/5 unit tests pass.
   Six raw off/on matches; smoke108/108, deliberate fault86/108 exit1. Default remains r2.
   After this single score: qualify or retain r2, then final nightly/PWA; no tuning loop.
4. All12 archived/current input files are byte-identical after the rebuild; report
   `20261123_r2_profile_refresh_identity_v1.json`. Exact controls remain reusable after parity. Archive
   `/Users/moholom/Basketball_archive_ops/archive_20261123T174020Z_91228` remains backup; never restore
   over production. Frozen r2 confirmation source31-file archive is under
   `data/derived/experiments/independent_rotation_policy_confirmation_20261123_v1_sources/`.
5. **Owner closing requests:** audit scorers on existing DEVELOPMENT evidence; verify team-total bias,
   player coverage and positive-minute/bench counts. Oracle rosters cannot test DNP forecasts.
   `20261123_closing_scorer_precheck_v1.json` confirms synthetic node-comparator zero-SE direction and
   silent-panel-drop bugs; implicit v2 default also needs explicit selection. Fix only after the frozen
   score finishes, preserving its archived source/results. Old S06 clears27/27 proper/current-policy
   development compatibility, not release permission; flag fresh current-baseline/coverage/seed
   confirmation as future work. No old protected rescoring or extra model-development round.
   Consolidate to five core docs (AGENTS/HANDOFF/PLAN/MODEL/README), retain necessary policy contracts,
   archive completed doc history/protocols together with hashes, update links/checker; report active
   file/word reductions. Preserve zone/order/zone-form hypotheses for later; no broad code refactor.
6. Finish A2 decision/delivery; review original S09 acceptance before crediting its10%. Required fresh
   full accepted-engine nightly, both PWA/iCloud checks, docs and commit/push. U23 is the delivered
   player-facing fallback if clock fails. Construct D54 successor fully at0 (weights/ten rungs/commands/
   acceptance/final nightly), then stop before A3/B/replay. No forecast-history backfill authorised.

First commands (A1 has finished; do not restart its jobs):

```sh
git status --short --branch
git --no-pager log --oneline -3
cat docs/protocols/a2_clock_v3_development_20261123.md
.venv/bin/python -m unittest tests.test_late_clock -v
.venv/bin/python scripts/check_docs.py
```

## Progress ladders — Chunk A

Headliners: lineup-aware player/game distributions; form/late-game realism; five saved games and 2-D replay.
Dependencies/acceptance are in PLAN §6a; methods/gates belong to ENGINE/TRAINING. Ten cumulative rungs/module;
100 includes evidence, necessary delivery, checks, docs and commit/push. Report every new 10% module/5% overall mark.

```text
Chunk A  ████████████░░░░░░░░ 58.0%
A2       ████████████████░░░░ 80%
A3       ░░░░░░░░░░░░░░░░░░░░ 0%
```

| Rung | A2 form / late game (35%) | A3 View Centre / delivery (35%) |
|---:|---|---|
| 10 | Quantify residual covariance after roles/minutes. | Freeze five-world selection, schema, provenance, spatial/data budget. |
| 20 | Freeze prior-fold talent/form hypotheses and no-double-count controls. | Select each team's maximum margin and maximum individual fantasy worlds. |
| 30 | Isolated uncertainty draws preserve means/streams (synthetic only so far). | Select a real representative world using frozen multi-stat distance. |
| 40 | Test shared pace/shooting and dependence on folds. | Persist five labels; validate local files and invalid/future-source contracts. |
| 50 | Audit late fouls, clock, shot selection and OT by supported states. | Capture/replay exact original batch events without changing draws. |
| 60 | Test supported state corrections against earlier-fold controls. | Independently reconcile event order, clocks, scores, boxes and legal fives. |
| 70 | Sequential player-first screens: CRPS, bias, coverage, joint metrics. | Ship stored-only court, overlays, box, event list and playback controls. |
| 80 | Test survivors together and under independent seeds. | Check seek/playback/accessibility, themes/widths, phone budget/offline. |
| 90 | Freeze promote/reject decision under all applicable gates. | Fresh live 10k nightly; audit selections and iCloud/PWA delivery. |
| 100 | Verify evidence/fallback/delivery, commit/push. | Publish shell; construct successor; checks, commit/push and summary. |

A1 is complete; its ladder/outcome is archived above. A2 90–100 and A3 all remain open. Chunk B's full predeclared ladders and the original S01–S14 ladders are preserved in
[the frozen planning record](docs/archive/2026-11-23-before-lean/HANDOFF_NEXT.md); open only the relevant section
when preparing that chunk, and copy its current ladder here before execution.
