# A2 contextual clock — current engine evidence

Research is active; production remains r2 with legacy timing. One frozen learned clock candidate,
unchanged v1.3 node recipes and r2 fitter in both arms. Original analytical primary improves conditional
time/no-action proper loss against both legacy and clean bridge; this alone does not qualify release.
See [active stages/policy](../protocols/a2_clock_v3_development_20261123.md).

| Complete stage | Games / paired player-games | Proper bounds | Coverage / cohort bias | Independent legal fives | Decision |
|---|---:|---:|---|---:|---|
| F4 development |200 /4,280|27/27|25/25 and17/17 established|228,336,846|Continue to earlier folds.|
| Supported F1 |100 /2,191|27/27|24/25 coverage,17/17 bias established; no material coverage harm|111,535,318|Continue; retain imprecise diagnostic.|
| Supported F2 |100 /2,120|27/27|25/25 coverage,17/17 bias established|111,233,574|Continue.|
| Supported F3 |100 /2,137|27/27|25/25 coverage,17/17 bias established|114,493,078|Continue.|
| Pooled earlier folds |300 /6,448|27/27|25/25 coverage,17/17 bias established|Parent audits;184 independent point checks|Continue.|
| Independent F4 |200 /4,297|27/27|25/25 coverage,17/17 bias established|227,982,928|Continue to seed/stress.|

F4 pooled MIN CRPS∆−.000598[−.001361,+.000135], PTS∆−.000151[−.001733,+.001406]; neither establishes
pooled accuracy improvement. Maximum replayed minute error1.07e−14. F1 pooled PTS CRPS∆−.002091
[−.004148,−.0000347] is exploratory, uncorrected and not the registered primary or a broad accuracy claim.
F2 pooled PTS CRPS∆−.000776[−.002916,+.001363] remains inconclusive; maximum minute error8.89e−15.
F3 PTS CRPS∆−.000997[−.003252,+.001191] is inconclusive. Pooled earlier PTS∆−.001296
[−.002531,−.0000590] is exploratory/uncorrected; MIN∆+.000477[−.000414,+.001300].
Independent F4 MIN∆+.000536[−.000205,+.001288], PTS∆+.001179[−.000388,+.002771]:
compatible, not established improvement; max minute error8.89e−15.
F1 total-coverage deviation∆+.003986[−.026014,+.031818] leaves the original.03 bound unresolved;
retain this diagnostic. Maximum F1 replayed minute error7.11e−15. Do not repeat completed scoring.

Namespaces under `analysis/experiments/`, each with `{,_audit,_compare,_compare_gate}.json`:
`a2_clock_development_20261123_v1`, `a2_clock_earlier_f1_supported_20261123_v1`,
`a2_clock_earlier_f2_supported_20261123_v1`, `a2_clock_earlier_f3_supported_20261123_v1`,
`a2_clock_earlier_pooled_supported_20261123_v1`, `a2_clock_confirmation_20261123_v1`. Pooling independently reconciles300 rows/6,448
player rows per arm and184 point scores; `20261123_a2_clock_pooled_accounting_v1.json`.
Counts are paired output rows; each statistic retains its own missing-truth/support count.
The complete reports retain all27 proper bounds,17 bias and25 coverage diagnostics, roles/missingness,
frozen node-primary evidence, capture hashes and paired complete-game bootstrap intervals.

## Readiness limitation and retained failed setup

The original F1 attempt failed on a missing position before any aggregate comparison/gate; ten complete
pairs and incomplete files remain retained. Per-game metrics were computed automatically but were not
inspected for selection. The executor hid the worker error while draining its queue; it was interrupted.
Receipt `20261123_a2_clock_f1_setup_failure_v1.json`. This is not a clock-model failure.

The prospective [readiness amendment](../protocols/a2_clock_readiness_amendment_20261123.md) audits only
frozen input rosters and strictly prior template positions:190/200 F1,190/200 F2 and179/200 F3 are usable.
Selecting the first100 supported games in the original hash order replaces4/5/15 original IDs without
changing the candidate, N, seeds, fitted parameters or gates. Missing positions stay missing. Full
600-game census/IDs/hashes: `20261123_a2_clock_ready_panels_v1.json`. Ten verified F1 pairs were reused
and independently re-audited. A separate raw-table reconstruction matches all600 readiness decisions/300
selected IDs,12,950 roster and127,610 prior-template position cells; receipt
`20261123_a2_clock_readiness_audit_v1.json`. Excluded-input games remain outside the resulting qualification population.

The generic companion logs incorrectly retain `seed_key:null` for earlier folds. Independent
accounting verifies all300 actual numeric seed pairs against the original `a2-clock-engine-F{1,2,3}-v1`
keys: `seed_for("backtest", key, date_et, game_id)`. Existing logs remain immutable;
`20261123_a2_clock_earlier_seed_accounting_v1.json` records this label correction, not a simulation change.

## Stored development-world diagnostics — mixed outcome

The200-game original F4 panel has2,333 actual late opportunities (16 invalid/unknown excluded),
3,635 eligible player-games per arm from4,280 paired rows. Each arm retains its own ≥8-minute selection;
identical counts alone do not prove identical membership. State visitation differs; these are descriptive
comparisons, not causal foul intent or a new acceptance threshold.

| Trailing4–8, Q4/OT ≤24s;52 actual games/113 opportunities | Actual | r2 control | Clock candidate |
|---|---:|---:|---:|
| Seconds to action |4.135|6.038|4.258|
| Defensive personal-foul share |6.195%|9.003%|13.355%|
| Three-point share of FGA |68.605%|57.114%|56.552%|

Action-time error falls+1.903s[+1.357,+2.414] to+.123s[−.414,+.630]. Foul-share error worsens
+2.808pp[−1.516,+6.843] to+7.160pp[+2.806,+11.210]; three selection remains weak. OT is4.0% actual,
2.7565% control/3.615% candidate; both simulated-minus-actual intervals include0. No universal late-game
accuracy claim, added variance or fitted foul/shot-selection variant follows from this inspection.

Reports `20261123_a2_clock_development_{control,candidate}_diagnostics_v1.json`. Exact executed source,
verified against both report hashes, is retained under
`data/derived/experiments/a2_world_diagnostics_arm_v1_sources/`. The subsequent `--panel confirmation`
selector repeats the same full diagnostics on the separately frozen200 IDs after that run; no bins,
fit, metric, cell support or gate changes. Report every supported cell, not just this example.

Independent F4 diagnostics have2,240 actual late opportunities (18 invalid/unknown excluded),
3,638/3,639 eligible player-games in control/candidate. The highlighted trailing4–8/≤24s cell has49
actual games but only78 opportunities: **unsupported** under the unchanged100 minimum; no forced
confirmation/rejection or lowered threshold. OT3.0% actual versus2.7645%/3.692% simulated, both
intervals include0. Full-state reports `20261123_a2_clock_confirmation_{control,candidate}_diagnostics_v1.json`.
Their exact executed selector source is in `data/derived/experiments/a2_world_diagnostics_panel_v2_sources/`.

## Still required

Independent-stream30, three10k stresses, then a frozen survivor's single protected r3
score. No protected r3 score has been generated. No bins, margins or variance factor may be chosen from
these outcomes. An unsupported/failed stage stays explicit; no automatic promotion. HANDOFF owns jobs.

Research checkpoint `20261123_a2_research_checkpoint_v1.json` covers F4/F1/F2: smoke108/108,
fault86/108 exit1, focused5/5. Later F3/pool/diagnostics are not a production change. Final A2 delivery remains required.
